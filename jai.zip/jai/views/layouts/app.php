<?php
// views/layouts/app.php — Unified Layout (Enhanced Orange Theme + Notifications + Waiter Support Pages)
// Updated: collapsible sidebar shows icon-only when collapsed (nav text hidden, tooltip shown)

if (session_status() === PHP_SESSION_NONE) session_start();

// Authentication check
if (empty($_SESSION['user_id']) || empty($_SESSION['role'])) {
    header("Location: ../../auth/login.php");
    exit;
}

$user_id      = $_SESSION['user_id'];
$user_role    = strtolower($_SESSION['role']);
$username     = $_SESSION['username'] ?? 'User';
$current_page = basename($_SERVER['PHP_SELF']);
$full_path    = $_SERVER['SCRIPT_NAME'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= ucfirst(htmlspecialchars($user_role)) ?> Dashboard | Mess Management</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>
:root {
  --brand:#ff8c42;
  --brand-dark:#e6762f;
  --bg:#f8f9fb;
  --text:#222;
  --muted:#6c757d;
  --sidebar-width:260px;
  --sidebar-mini:70px;
  --transition:all .25s ease-in-out;
}
html,body{height:100%}
body {
  font-family:'Poppins',sans-serif;
  background:var(--bg);
  color:var(--text);
  padding-top:64px;
  transition:background .4s,color .4s;
}
body.dark-mode {
  --bg:#1e1e1e;
  --text:#e6e6e6;
  --muted:#b5b5b5;
  background:var(--bg);
  color:var(--text);
}

/* Navbar */
.navbar-fixed {
  position:fixed;top:0;left:0;right:0;height:64px;
  background:linear-gradient(90deg,var(--brand-dark) 0%,var(--brand) 100%);
  color:#fff;z-index:1100;display:flex;align-items:center;justify-content:space-between;
  padding:0 1rem;box-shadow:0 3px 10px rgba(0,0,0,0.08);
}
.navbar-fixed .navbar-brand {
  color:#fff;text-decoration:none;font-weight:600;display:flex;align-items:center;gap:.5rem;
}
.navbar-fixed .dropdown-menu {
  border-radius:10px;box-shadow:0 5px 15px rgba(0,0,0,0.15);
}

/* Sidebar */
.sidebar {
  position:fixed;top:64px;left:0;height:calc(100vh - 64px);
  width:var(--sidebar-width);background:#fff;border-right:1px solid #eee;
  transition:var(--transition);overflow-y:auto;z-index:1050;
}
body.dark-mode .sidebar { background:#262626;border-color:#333; }
.sidebar.collapsed { width:var(--sidebar-mini); }

/* Brand area */
.sidebar .brand-area {
  padding:1.80rem;border-bottom:1px solid #eee;display:flex;align-items:center;gap:0.5rem;
}
.sidebar .brand-text { font-weight:600;color:var(--text); }
.sidebar.collapsed .brand-text { display:none; }

/* Nav items */
.sidebar .nav { padding:1rem 0; }
.sidebar .nav-link {
  display:flex;align-items:center;gap:.75rem;color:var(--muted);
  padding:.65rem 1rem;margin:.25rem .5rem;border-radius:8px;text-decoration:none;
  transition:var(--transition);
  white-space:nowrap;
}
.sidebar .nav-link i { width:26px;text-align:center;font-size:1.2rem; }

/* label span so we can hide on collapse */
.sidebar .nav-text { display:inline-block; }

/* hover / active */
.sidebar .nav-link:hover { background:rgba(255,140,66,0.15);color:var(--brand-dark); }
.sidebar .nav-link.active {
  background:rgba(255,140,66,0.25);color:var(--brand-dark);
  font-weight:600;border-left:3px solid var(--brand-dark);
}

/* ===== collapsed behavior: show icon-only and center icons ===== */
.sidebar.collapsed .nav-link {
  justify-content:center;
  padding-left:0.5rem;
  padding-right:0.5rem;
}
.sidebar.collapsed .nav-link i { margin:0; }
.sidebar.collapsed .nav-text { display:none; }

/* show tooltip cursor when collapsed */
.sidebar.collapsed .nav-link { position:relative; cursor:default; }

/* Main content */
.main-content {
  margin-left:var(--sidebar-width);
  padding:1.75rem;transition:var(--transition);min-height:calc(100vh - 64px);
}
.sidebar.collapsed ~ .main-content { margin-left:var(--sidebar-mini); }

.card { border:none;border-radius:12px;box-shadow:0 4px 12px rgba(0,0,0,0.05);transition:var(--transition); }
.card:hover{ transform:translateY(-3px); }
.page-title-box {
  background:#fff;border-left:6px solid var(--brand);border-radius:12px;
  padding:1.25rem;margin-bottom:1.5rem;box-shadow:0 4px 12px rgba(0,0,0,0.05);
}
body.dark-mode .page-title-box, body.dark-mode .card {
  background:#2b2b2b;box-shadow:0 0 10px rgba(255,255,255,0.05);
}

.btn-brand { background:var(--brand);color:#fff;border:none;border-radius:8px;padding:.55rem 1rem; }
.btn-brand:hover { background:var(--brand-dark); }

footer { text-align:center;font-size:.85rem;color:var(--muted);margin-top:2rem;padding:1rem 0; }

/* responsive */
@media (max-width:768px){
  .sidebar { transform:translateX(-100%); }
  .sidebar.active { transform:translateX(0); }
  .main-content { margin-left:0; }
}
.fade-in { animation:fadeIn .4s ease-in-out; }
@keyframes fadeIn { from{opacity:0;transform:translateY(5px);} to{opacity:1;transform:translateY(0);} }
</style>
</head>
<body>

<!-- Navbar -->
<header class="navbar-fixed">
  <div class="d-flex align-items-center">
    <button id="sidebarToggle" class="btn btn-link text-white me-2" aria-label="Toggle sidebar"><i class="bi bi-list"></i></button>
    <a href="#" class="navbar-brand"><i class="bi bi-shop-window"></i> Mess Management</a>
  </div>

  <div class="d-flex align-items-center gap-3">
    <?php if ($user_role === 'waiter'): ?>
      <div class="dropdown me-3" id="notifDropdown">
        <button class="btn btn-link text-white position-relative" id="notifButton" data-bs-toggle="dropdown" aria-expanded="false">
          <i class="bi bi-bell-fill fs-5"></i>
          <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="notifCount" style="display:none;">0</span>
        </button>
        <ul class="dropdown-menu dropdown-menu-end shadow-sm p-0" id="notifMenu" style="width:320px;max-height:360px;overflow-y:auto;">
          <li class="dropdown-header text-center py-2 fw-semibold bg-light">Notifications</li>
          <li id="notifItems"><div class="p-3 text-center text-muted small">No new notifications</div></li>
        </ul>
      </div>
    <?php endif; ?>

    <button id="themeToggle" class="btn btn-link text-white" aria-label="Toggle theme"><i class="bi bi-moon"></i></button>

    <div class="dropdown">
      <a href="#" class="text-white dropdown-toggle fw-medium" data-bs-toggle="dropdown">
        <i class="bi bi-person-circle me-1"></i><?= htmlspecialchars($username) ?>
      </a>
      <ul class="dropdown-menu dropdown-menu-end shadow-sm">
        <li><a class="dropdown-item" href="../<?= $user_role ?>/profile.php"><i class="bi bi-person me-2"></i>Profile</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item text-danger" href="../../../logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
      </ul>
    </div>
  </div>
</header>

<!-- Sidebar -->
<aside id="appSidebar" class="sidebar" role="navigation" aria-label="Main sidebar">
  <div class="brand-area">
    <i class="bi bi-shop" style="color:var(--brand);font-size:1.25rem;"></i>
    <span class="brand-text">Mess Management</span>
  </div>

  <ul class="nav flex-column mt-3">
    <li>
      <a class="nav-link <?= $current_page==='index.php'?'active':'' ?>"
         href="../<?= $user_role ?>/index.php"
         title="Dashboard">
        <i class="bi bi-speedometer2"></i>
        <span class="nav-text">Dashboard</span>
      </a>
    </li>

    <?php if ($user_role === 'waiter'): ?>
      <li>
        <a class="nav-link <?= strpos($full_path,'support_order')!==false?'active':'' ?>"
           href="../waiter/support_order.php"
           title="Support / Create Order">
          <i class="bi bi-headset"></i>
          <span class="nav-text">Support / Create Order</span>
        </a>
      </li>

      <li>
        <a class="nav-link <?= strpos($full_path,'orders')!==false?'active':'' ?>"
           href="../waiter/orders.php"
           title="Orders">
          <i class="bi bi-list-check"></i>
          <span class="nav-text">Orders</span>
        </a>
      </li>

      <li>
        <a class="nav-link <?= strpos($full_path,'tables')!==false?'active':'' ?>"
           href="../waiter/tables.php"
           title="Tables">
          <i class="bi bi-grid"></i>
          <span class="nav-text">Tables</span>
        </a>
      </li>
    <?php endif; ?>

    <?php if ($user_role === 'admin'): ?>
      <li><a class="nav-link <?= strpos($full_path,'users')!==false?'active':'' ?>" href="../admin/users.php" title="Users"><i class="bi bi-people"></i><span class="nav-text">Users</span></a></li>
      <li><a class="nav-link <?= strpos($full_path,'menu')!==false?'active':'' ?>" href="../admin/menu.php" title="Menu"><i class="bi bi-list"></i><span class="nav-text">Menu</span></a></li>
      <li><a class="nav-link <?= strpos($full_path,'transactions')!==false?'active':'' ?>" href="../admin/transactions.php" title="Transactions"><i class="bi bi-receipt"></i><span class="nav-text">Transactions</span></a></li>
    <?php endif; ?>

    <?php if ($user_role === 'user'): ?>
      <li><a class="nav-link <?= strpos($full_path,'my_orders')!==false?'active':'' ?>" href="../user/my_orders.php" title="My Orders"><i class="bi bi-basket"></i><span class="nav-text">My Orders</span></a></li>
      <li><a class="nav-link <?= strpos($full_path,'profile')!==false?'active':'' ?>" href="../user/profile.php" title="Profile"><i class="bi bi-person"></i><span class="nav-text">Profile</span></a></li>
    <?php endif; ?>
  </ul>
</aside>

<!-- Main content -->
<main class="main-content fade-in" id="mainContent" role="main">
  <?= $content ?? ''; ?>
  <footer>© <?= date('Y') ?> Mess Management System</footer>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const sidebar = document.getElementById('appSidebar');
const sidebarToggle = document.getElementById('sidebarToggle');
const themeToggle = document.getElementById('themeToggle');

// Sidebar toggle (collapse/expand)
sidebarToggle.addEventListener('click', () => {
  if (window.innerWidth <= 768) {
    sidebar.classList.toggle('active'); // mobile show/hide
  } else {
    sidebar.classList.toggle('collapsed'); // desktop collapsed icon-only
  }
});

// Close sidebar on mobile link click
sidebar.querySelectorAll('a.nav-link').forEach(link => {
  link.addEventListener('click', () => {
    if (window.innerWidth <= 768) sidebar.classList.remove('active');
  });
});

// Theme toggle
function setTheme(isDark) {
  document.body.classList.toggle('dark-mode', isDark);
  themeToggle.innerHTML = isDark ? '<i class="bi bi-sun"></i>' : '<i class="bi bi-moon"></i>';
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
}
setTheme(localStorage.getItem('theme') === 'dark');
themeToggle.addEventListener('click', () => setTheme(!document.body.classList.contains('dark-mode')));

// Waiter notifications
<?php if ($user_role === 'waiter'): ?>
function loadNotifications() {
  fetch('../waiter/fetch_notifications.php')
    .then(r => r.json())
    .then(data => {
      const menu = document.getElementById('notifItems');
      const count = document.getElementById('notifCount');
      if (!data || !data.length) {
        menu.innerHTML = '<div class="p-3 text-center text-muted small">No new notifications</div>';
        count.style.display = 'none';
        return;
      }
      count.textContent = data.length;
      count.style.display = 'inline-block';
      menu.innerHTML = data.map(n => `
        <li class="border-bottom px-3 py-2 d-flex justify-content-between align-items-start">
          <div class="small text-dark">${n.message}</div>
          <button class="btn btn-sm btn-outline-danger ms-2 p-0 px-1" title="Mark as read" onclick="markAsRead(${n.id})">
            <i class="bi bi-x-lg"></i>
          </button>
        </li>
      `).join('');
    })
    .catch(console.error);
}

function markAsRead(id) {
  fetch('../waiter/mark_notification.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: 'id=' + id
  }).then(() => loadNotifications());
}

setInterval(loadNotifications, 10000);
loadNotifications();
<?php endif; ?>
</script>
</body>
</html>
