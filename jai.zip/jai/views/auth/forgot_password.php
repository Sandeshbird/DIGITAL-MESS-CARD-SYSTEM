<?php
// views/auth/forgot_password.php

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Redirect logged-in users
if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    $role = $_SESSION['role'];
    if ($role === 'admin') {
        header("Location: ../dashboard/admin/index.php");
    } elseif ($role === 'waiter') {
        header("Location: ../dashboard/waiter/index.php");
    } else {
        header("Location: ../dashboard/user/index.php");
    }
    exit;
}

require_once '../../config/database.php';

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login_input = trim($_POST['login_input'] ?? '');

    if (!empty($login_input)) {
        try {
            $database = new Database();
            $db = $database->getConnection();

            if (!$db) {
                die("Database connection failed!");
            }

            // ✅ Proper placeholders (fixes HY093)
            $query = "SELECT id, email, ph_no FROM user WHERE email = :email OR ph_no = :phone LIMIT 1";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':email', $login_input);
            $stmt->bindParam(':phone', $login_input);
            $stmt->execute();

            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // ✅ Generate secure reset token
                $token = bin2hex(random_bytes(32));
                $expires = date('Y-m-d H:i:s', strtotime('+15 minutes'));

                $updateQuery = "UPDATE user SET reset_token = :token, reset_expires = :expires WHERE id = :id";
                $updateStmt = $db->prepare($updateQuery);
                $updateStmt->bindParam(':token', $token);
                $updateStmt->bindParam(':expires', $expires);
                $updateStmt->bindParam(':id', $user['id']);
                $updateStmt->execute();

                // ✅ Construct reset link
                $resetLink = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/reset_password.php?token=" . $token;

                // ⚡ Optional: send email or SMS
                // mail($user['email'], "Password Reset", "Click the link to reset your password: $resetLink");

                $success_message = "A password reset link has been generated successfully.<br><a href='$resetLink' target='_blank'>Click here to reset your password</a>";
            } else {
                $error_message = "No account found with that email or phone number.";
            }
        } catch (PDOException $e) {
            $error_message = "Database error: " . $e->getMessage();
            error_log("Forgot Password Error: " . $e->getMessage());
        }
    } else {
        $error_message = "Please enter your registered email or phone number.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Forgot Password - Mess Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #6f42c1 0%, #5a32a3 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .card {
            border-radius: 15px;
        }
    </style>
</head>
<body>
<div class="col-md-5 col-lg-4">
    <div class="card shadow">
        <div class="card-header text-center bg-primary text-white">
            <h4><i class="bi bi-unlock-fill me-2"></i>Forgot Password</h4>
        </div>
        <div class="card-body">

            <?php if ($error_message): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($error_message) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php elseif ($success_message): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?= $success_message ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <form method="post" action="">
                <div class="mb-3">
                    <label for="login_input" class="form-label">Email or Phone Number</label>
                    <input type="text" class="form-control" id="login_input" name="login_input"
                           placeholder="Enter your registered email or phone number"
                           value="<?= htmlspecialchars($_POST['login_input'] ?? '') ?>" required>
                    <small id="input_hint" class="form-text text-muted">
                        Enter the email or phone number linked to your account.
                    </small>
                </div>

                <div class="d-grid mb-3">
                    <button type="submit" class="btn btn-primary">Send Reset Link</button>
                </div>

                <div class="text-center mt-3">
                    <a href="login.php" class="text-decoration-none">Back to Login</a> |
                    <a href="signup.php" class="text-decoration-none">Sign Up</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
const inputField = document.getElementById('login_input');
const hint = document.getElementById('input_hint');

inputField.addEventListener('input', () => {
    const value = inputField.value.trim();
    if (/^\d{10}$/.test(value)) {
        hint.textContent = "Phone number detected.";
        hint.className = "form-text text-success";
    } else if (/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(value)) {
        hint.textContent = "Email address detected.";
        hint.className = "form-text text-success";
    } else {
        hint.textContent = "Enter the email or phone number linked to your account.";
        hint.className = "form-text text-muted";
    }
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
