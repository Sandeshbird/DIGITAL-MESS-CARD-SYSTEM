<?php
// views/auth/login.php

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    $role = $_SESSION['role'];
    if ($role === 'admin') {
        header("Location: ../dashboard/admin/index.php");
    } elseif ($role === 'waiter') {
        header("Location: ../dashboard/waiter/index.php");
    } else {
        header("Location: ../dashboard/user/index.php");
    }
    exit;
}

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login_input = trim($_POST['login_input'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!empty($login_input) && !empty($password)) {
        require_once '../../config/database.php';

        try {
            $database = new Database();
            $db = $database->getConnection();

            if (!$db) {
                die("Database connection failed!");
            }

            // ✅ Fix: separate placeholders to prevent HY093 error
            $query = "
                SELECT id, username, password, role, status, first_name, last_name
                FROM user
                WHERE status = 1
                AND (
                    username = :username_input
                    OR email = :email_input
                    OR ph_no = :phone_input
                )
                LIMIT 1
            ";

            $stmt = $db->prepare($query);
            $stmt->bindValue(':username_input', $login_input);
            $stmt->bindValue(':email_input', $login_input);
            $stmt->bindValue(':phone_input', $login_input);
            $stmt->execute();

            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];

                // ✅ Role-based redirect
                if ($user['role'] === 'admin') {
                    header("Location: ../dashboard/admin/index.php");
                } elseif ($user['role'] === 'waiter') {
                    header("Location: ../dashboard/waiter/index.php");
                } else {
                    header("Location: ../dashboard/user/index.php");
                }
                exit;
            } else {
                $error_message = "Invalid credentials or inactive account.";
            }
        } catch (PDOException $e) {
            $error_message = "Database error: " . htmlspecialchars($e->getMessage());
            error_log("Login error: " . $e->getMessage());
        }
    } else {
        $error_message = "Please enter your email/phone/username and password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login - Mess Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #6f42c1 0%, #5a32a3 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .card {
            border-radius: 15px;
        }
    </style>
</head>
<body>
<div class="col-md-5 col-lg-4">
    <div class="card shadow">
        <div class="card-header text-center bg-primary text-white">
            <h4><i class="bi bi-person-circle me-2"></i>Login</h4>
        </div>
        <div class="card-body">
            <?php if ($error_message): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($error_message) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <form method="post" action="">
                <div class="mb-3">
                    <label for="login_input" class="form-label">Email / Phone / Username</label>
                    <input type="text" class="form-control" id="login_input" name="login_input"
                           placeholder="Enter your email, phone, or username"
                           value="<?= htmlspecialchars($_POST['login_input'] ?? '') ?>" required>
                    <small id="login_hint" class="form-text text-muted">
                        You can log in using your email, phone number, or username.
                    </small>
                </div>

                <div class="mb-3 position-relative">
                    <label for="password" class="form-label">Password</label>
                    <div class="input-group">
                        <input type="password" class="form-control" id="password" name="password" required>
                        <button type="button" class="btn btn-outline-secondary" id="togglePassword">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                </div>

                <div class="d-grid mb-3">
                    <button type="submit" class="btn btn-primary">Login</button>
                </div>

                <div class="text-center mt-3">
                    <a href="forgot_password.php" class="text-decoration-none">Forgot Password?</a>
                    <span class="mx-2">|</span>
                    <a href="signup.php" class="text-decoration-none">Sign up</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
const loginInput = document.getElementById('login_input');
const loginHint = document.getElementById('login_hint');
const passwordInput = document.getElementById('password');
const togglePassword = document.getElementById('togglePassword');

// Detect login type
loginInput.addEventListener('input', () => {
    const value = loginInput.value.trim();
    if (/^\d{10}$/.test(value)) {
        loginHint.textContent = "Phone number detected.";
        loginHint.className = "form-text text-success";
    } else if (/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(value)) {
        loginHint.textContent = "Email address detected.";
        loginHint.className = "form-text text-success";
    } else if (value.length > 0) {
        loginHint.textContent = "Username detected.";
        loginHint.className = "form-text text-success";
    } else {
        loginHint.textContent = "You can log in using your email, phone, or username.";
        loginHint.className = "form-text text-muted";
    }
});

// Toggle password visibility
togglePassword.addEventListener('click', () => {
    const type = passwordInput.type === 'password' ? 'text' : 'password';
    passwordInput.type = type;
    togglePassword.innerHTML = type === 'password'
        ? "<i class='bi bi-eye'></i>"
        : "<i class='bi bi-eye-slash'></i>";
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
