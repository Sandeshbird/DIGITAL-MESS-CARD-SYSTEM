<?php
// views/auth/signup.php

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    $role = $_SESSION['role'];
    if ($role === 'admin') {
        header("Location: ../dashboard/admin/index.php");
    } elseif ($role === 'waiter') {
        header("Location: ../dashboard/waiter/index.php");
    } else {
        header("Location: ../dashboard/user/index.php");
    }
    exit;
}

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $email_or_phone = trim($_POST['email_or_phone'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $role = $_POST['role'] ?? 'user'; // ✅ user selects role now

    $errors = [];
    $email = '';
    $ph_no = '';

    // Detect email or phone
    if (filter_var($email_or_phone, FILTER_VALIDATE_EMAIL)) {
        $email = $email_or_phone;
    } elseif (is_numeric($email_or_phone) && strlen($email_or_phone) === 10) {
        $ph_no = $email_or_phone;
    } else {
        $errors[] = "Please enter a valid email or 10-digit phone number.";
    }

    if (empty($first_name) || empty($last_name) || empty($email_or_phone) || empty($username) || empty($password) || empty($confirm_password) || empty($gender)) {
        $errors[] = "All fields are required.";
    }

    if ($password !== $confirm_password) {
        $errors[] = "Passwords do not match.";
    }

    if (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters long.";
    }

    if (!in_array($gender, ['Male', 'Female', 'Other'])) {
        $errors[] = "Invalid gender selected.";
    }

    if (empty($errors)) {
        require_once '../../config/database.php';

        try {
            $database = new Database();
            $db = $database->getConnection();

            $check_query = "SELECT id FROM user WHERE username = :username OR email = :email OR ph_no = :ph_no LIMIT 1";
            $check_stmt = $db->prepare($check_query);
            $check_stmt->bindParam(':username', $username);
            $check_stmt->bindParam(':email', $email);
            $check_stmt->bindParam(':ph_no', $ph_no);
            $check_stmt->execute();

            if ($check_stmt->rowCount() > 0) {
                $error_message = "Username, Email, or Phone number already exists.";
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                $insert_query = "INSERT INTO user (first_name, last_name, email, ph_no, username, password, status, role, gender)
                                 VALUES (:first_name, :last_name, :email, :ph_no, :username, :password, 1, :role, :gender)";
                $insert_stmt = $db->prepare($insert_query);
                $insert_stmt->bindParam(':first_name', $first_name);
                $insert_stmt->bindParam(':last_name', $last_name);
                $insert_stmt->bindParam(':email', $email);
                $insert_stmt->bindParam(':ph_no', $ph_no);
                $insert_stmt->bindParam(':username', $username);
                $insert_stmt->bindParam(':password', $hashed_password);
                $insert_stmt->bindParam(':role', $role);
                $insert_stmt->bindParam(':gender', $gender);

                if ($insert_stmt->execute()) {
                    // ✅ Log the user in automatically
                    $_SESSION['user_id'] = $db->lastInsertId();
                    $_SESSION['username'] = $username;
                    $_SESSION['role'] = $role;

                    // ✅ Redirect based on role
                    if ($role === 'admin') {
                        header("Location: ../dashboard/admin/index.php");
                    } elseif ($role === 'waiter') {
                        header("Location: ../dashboard/waiter/index.php");
                    } else {
                        header("Location: ../dashboard/user/index.php");
                    }
                    exit;
                } else {
                    $error_message = "Registration failed. Please try again.";
                }
            }
        } catch (PDOException $e) {
            $error_message = "Database error. Please try again later.";
            error_log("Signup error: " . $e->getMessage());
        }
    } else {
        $error_message = implode("<br>", $errors);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up - Mess Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #6f42c1, #5a32a3);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .card {
            border-radius: 15px;
        }
    </style>
</head>
<body>
<div class="col-md-6 col-lg-5">
    <div class="card shadow">
        <div class="card-header text-center bg-primary text-white">
            <h4><i class="bi bi-person-plus-fill me-2"></i>Sign Up</h4>
        </div>
        <div class="card-body">
            <?php if ($success_message): ?>
                <div class="alert alert-success"><?= htmlspecialchars($success_message) ?></div>
            <?php elseif ($error_message): ?>
                <div class="alert alert-danger"><?= $error_message ?></div>
            <?php endif; ?>

            <form method="post" action="">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">First Name</label>
                        <input type="text" class="form-control" name="first_name" value="<?= htmlspecialchars($_POST['first_name'] ?? '') ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Last Name</label>
                        <input type="text" class="form-control" name="last_name" value="<?= htmlspecialchars($_POST['last_name'] ?? '') ?>" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Email or Phone</label>
                    <input type="text" class="form-control" id="email_or_phone" name="email_or_phone"
                           placeholder="Enter email or phone number"
                           value="<?= htmlspecialchars($_POST['email_or_phone'] ?? '') ?>" required>
                    <small id="email_phone_hint" class="form-text text-muted">Enter a valid email or 10-digit phone number.</small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Username</label>
                    <input type="text" class="form-control" name="username" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Gender</label>
                    <select class="form-select" name="gender" required>
                        <option value="">Select Gender</option>
                        <option value="Male" <?= (($_POST['gender'] ?? '') === 'Male' ? 'selected' : '') ?>>Male</option>
                        <option value="Female" <?= (($_POST['gender'] ?? '') === 'Female' ? 'selected' : '') ?>>Female</option>
                        <option value="Other" <?= (($_POST['gender'] ?? '') === 'Other' ? 'selected' : '') ?>>Other</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Role</label>
                    <select class="form-select" name="role" required>
                        <option value="user" <?= (($_POST['role'] ?? '') === 'user' ? 'selected' : '') ?>>User</option>
                        <option value="waiter" <?= (($_POST['role'] ?? '') === 'waiter' ? 'selected' : '') ?>>Waiter</option>
                        <option value="admin" <?= (($_POST['role'] ?? '') === 'admin' ? 'selected' : '') ?>>Admin</option>
                    </select>
                </div>

                <div class="mb-3 position-relative">
                    <label class="form-label">Password</label>
                    <div class="input-group">
                        <input type="password" class="form-control" id="password" name="password" required>
                        <button type="button" class="btn btn-outline-secondary" id="togglePassword"><i class="bi bi-eye"></i></button>
                    </div>
                    <small id="password_strength" class="form-text"></small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Confirm Password</label>
                    <input type="password" class="form-control" name="confirm_password" required>
                </div>

                <div class="d-grid mb-2">
                    <button type="submit" class="btn btn-primary">Sign Up</button>
                </div>

                <div class="text-center">
                    Already have an account? <a href="login.php">Login here</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
const emailPhoneInput = document.getElementById('email_or_phone');
const emailPhoneHint = document.getElementById('email_phone_hint');
const passwordInput = document.getElementById('password');
const passwordStrength = document.getElementById('password_strength');
const togglePassword = document.getElementById('togglePassword');

emailPhoneInput.addEventListener('input', () => {
    const value = emailPhoneInput.value.trim();
    if (/^\d{10}$/.test(value)) {
        emailPhoneHint.textContent = "Phone number detected.";
        emailPhoneHint.className = "form-text text-success";
    } else if (/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(value)) {
        emailPhoneHint.textContent = "Email address detected.";
        emailPhoneHint.className = "form-text text-success";
    } else {
        emailPhoneHint.textContent = "Enter a valid email or 10-digit phone number.";
        emailPhoneHint.className = "form-text text-muted";
    }
});

togglePassword.addEventListener('click', () => {
    const type = passwordInput.type === 'password' ? 'text' : 'password';
    passwordInput.type = type;
    togglePassword.innerHTML = type === 'password' ? "<i class='bi bi-eye'></i>" : "<i class='bi bi-eye-slash'></i>";
});

passwordInput.addEventListener('input', () => {
    const val = passwordInput.value;
    let strength = 0;
    if (val.length >= 6) strength++;
    if (/[A-Z]/.test(val)) strength++;
    if (/[0-9]/.test(val)) strength++;
    if (/[@$!%*?&#]/.test(val)) strength++;

    const strengthText = ["Weak", "Fair", "Good", "Strong"];
    const colors = ["red", "orange", "blue", "green"];
    passwordStrength.textContent = "Strength: " + strengthText[strength - 1] || "";
    passwordStrength.style.color = colors[strength - 1] || "black";
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
