<?php
// views/dashboard/admin/orders.php
// SIMPLE VERSION - NO AUTHENTICATION AT ALL

// ONLY session start - NOTHING ELSE
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$user_name = $_SESSION['username'] ?? 'Admin';
define('BASE_PATH', dirname(__DIR__, 3));

require_once BASE_PATH . '/config/database.php';
$database = new Database();
$db = $database->getConnection();

// Simple test query to check if database works
try {
    $stmt = $db->query("SELECT COUNT(*) as count FROM orders");
    $result = $stmt->fetch();
    $order_count = $result['count'];
} catch (Exception $e) {
    $order_count = 'Error';
}

ob_start();
?>

<div class="page-title-box">
    <h2><i class="bi bi-list-check"></i> Orders Management</h2>
    <p class="text-muted mb-0">Welcome, <?= htmlspecialchars($user_name) ?></p>
</div>

<div class="card">
    <div class="card-body">
        <h4>Orders Page Loaded Successfully!</h4>
        <p>Database connection: ✅ Working</p>
        <p>Total orders in database: <?= $order_count ?></p>
        <p>User role: <?= $_SESSION['role'] ?? 'Not set' ?></p>
        
        <div class="mt-4">
            <a href="?action=create" class="btn btn-brand">Create Order</a>
            <a href="orders.php" class="btn btn-secondary">Refresh</a>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
include BASE_PATH . '/views/layouts/app.php';
?>