<?php
// views/dashboard/admin/menu.php — Unified Admin Menu Management (Connected with Waiter Menu)

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../auth/login.php");
    exit;
}

require_once '../../../config/database.php';
$database = new Database();
$db = $database->getConnection();

$user_name = $_SESSION['username'] ?? 'Admin';
$message = '';
$message_type = '';

// Handle delete menu item
if (isset($_GET['delete'])) {
    $delete_id = (int) $_GET['delete'];
    try {
        $stmt = $db->prepare("DELETE FROM menu WHERE id = ?");
        $stmt->execute([$delete_id]);
        $message = "Menu item deleted successfully!";
        $message_type = "success";
    } catch (PDOException $e) {
        $message = "Error deleting item.";
        $message_type = "danger";
        error_log("Delete menu error: " . $e->getMessage());
    }
}

// Handle new item submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_menu'])) {
    $type = trim($_POST['menu_type']);
    $category = trim($_POST['category']);
    $description = trim($_POST['description']);
    $price = floatval($_POST['price']);

    if ($type && $category && $description && $price > 0) {
        try {
            $stmt = $db->prepare("INSERT INTO menu (menu_type, category, description, price, created_at) VALUES (?, ?, ?, ?, NOW())");
            $stmt->execute([$type, $category, $description, $price]);
            $message = "Menu item added successfully!";
            $message_type = "success";
        } catch (PDOException $e) {
            $message = "Error adding item.";
            $message_type = "danger";
            error_log("Add menu error: " . $e->getMessage());
        }
    } else {
        $message = "Please fill all fields correctly.";
        $message_type = "warning";
    }
}

// Fetch all menu items
try {
    $stmt = $db->query("SELECT * FROM menu ORDER BY category, menu_type, created_at DESC");
    $menu_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $menu_items = [];
    error_log("Menu fetch error: " . $e->getMessage());
}

ob_start();
?>

<div class="container-fluid py-3">
  <div class="page-title-box d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0">Manage Menu</h3>
    <a href="index.php" class="btn btn-sm btn-warning"><i class="bi bi-house"></i> Dashboard</a>
  </div>

  <?php if ($message): ?>
    <div class="alert alert-<?= $message_type ?> alert-dismissible fade show" role="alert">
      <?= htmlspecialchars($message) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <!-- Add New Menu Item -->
  <div class="card mb-4">
    <div class="card-header bg-light fw-bold"><i class="bi bi-plus-circle me-2"></i>Add Menu Item</div>
    <div class="card-body">
      <form method="POST">
        <div class="row g-3">
          <div class="col-md-3">
            <label class="form-label">Type</label>
            <select name="menu_type" class="form-select" required>
              <option value="">Select Type</option>
              <option value="Veg">Veg</option>
              <option value="Non-Veg">Non-Veg</option>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label">Category</label>
            <input type="text" name="category" class="form-control" placeholder="e.g. Starters, Main Course" required>
          </div>
          <div class="col-md-4">
            <label class="form-label">Description</label>
            <input type="text" name="description" class="form-control" placeholder="e.g. Paneer Butter Masala" required>
          </div>
          <div class="col-md-2">
            <label class="form-label">Price (₹)</label>
            <input type="number" name="price" class="form-control" min="1" step="0.01" required>
          </div>
        </div>
        <div class="text-end mt-3">
          <button type="submit" name="add_menu" class="btn btn-success px-4"><i class="bi bi-check-lg"></i> Add Item</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Menu List -->
  <div class="card">
    <div class="card-header bg-light fw-bold"><i class="bi bi-list-ul me-2"></i>All Menu Items</div>
    <div class="card-body">
      <?php if (empty($menu_items)): ?>
        <div class="text-center py-4">
          <i class="bi bi-card-list" style="font-size:3rem;color:#ccc;"></i>
          <h5>No items found</h5>
          <p class="text-muted">Start by adding menu items above.</p>
        </div>
      <?php else: ?>
        <div class="table-responsive">
          <table class="table table-striped align-middle">
            <thead class="table-dark">
              <tr>
                <th>ID</th>
                <th>Type</th>
                <th>Category</th>
                <th>Description</th>
                <th>Price (₹)</th>
                <th>Created At</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($menu_items as $item): ?>
              <tr>
                <td><?= $item['id'] ?></td>
                <td><?= htmlspecialchars($item['menu_type']) ?></td>
                <td><?= htmlspecialchars($item['category']) ?></td>
                <td><?= htmlspecialchars($item['description']) ?></td>
                <td><?= number_format($item['price'], 2) ?></td>
                <td><?= date('M d, Y h:i A', strtotime($item['created_at'])) ?></td>
                <td>
                  <a href="?delete=<?= $item['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this item?')">
                    <i class="bi bi-trash"></i>
                  </a>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php
$content = ob_get_clean();
include '../../layouts/app.php';
?>
