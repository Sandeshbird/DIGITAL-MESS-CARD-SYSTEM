<?php
// views/dashboard/waiter/scan_qr.php — Scan QR + Select Menu + Place Order (Unified)
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'waiter') {
    header("Location: ../../auth/login.php");
    exit;
}

require_once '../../../config/database.php';
$database = new Database();
$db = $database->getConnection();

$waiter_id = $_SESSION['user_id'];
$waiter_name = $_SESSION['username'] ?? 'Waiter';
$message = '';
$message_type = '';

$table = null;
$menu_items = [];

// ✅ Step 1: Handle QR / Table Code Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['scan_qr'])) {
    $qr_code = trim($_POST['qr_code'] ?? '');

    if ($qr_code === '') {
        $message = 'Please enter or scan a QR code.';
        $message_type = 'danger';
    } else {
        try {
            $stmt = $db->prepare("SELECT * FROM tables WHERE t_qr = :tqr LIMIT 1");
            $stmt->execute([':tqr' => $qr_code]);
            $table = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($table) {
                $_SESSION['table_id'] = $table['id'];
                $_SESSION['table_name'] = $table['t_name'];

                // Fetch menu from admin's menu table
                $menu_stmt = $db->prepare("SELECT * FROM menu ORDER BY category, name");
                $menu_stmt->execute();
                $menu_items = $menu_stmt->fetchAll(PDO::FETCH_ASSOC);
            } else {
                $message = 'Invalid QR Code — No matching table found.';
                $message_type = 'danger';
            }
        } catch (PDOException $e) {
            $message = 'Database error while verifying table.';
            $message_type = 'danger';
        }
    }
}

// ✅ Step 2: Handle Order Placement
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    $selected_items = $_POST['items'] ?? [];
    $quantities = $_POST['quantities'] ?? [];

    if (empty($selected_items)) {
        $message = 'Please select at least one menu item.';
        $message_type = 'danger';
    } else {
        try {
            $table_id = $_SESSION['table_id'];
            $total_amount = 0;

            // Calculate total
            foreach ($selected_items as $item_id) {
                $stmt = $db->prepare("SELECT price FROM menu WHERE id = ?");
                $stmt->execute([$item_id]);
                $price = $stmt->fetchColumn();
                $total_amount += $price * ($quantities[$item_id] ?? 1);
            }

            // Create order
            $order_stmt = $db->prepare("
                INSERT INTO orders (table_id, user_id, total_amount, status, order_time)
                VALUES (?, ?, ?, 'pending', NOW())
            ");
            $order_stmt->execute([$table_id, $waiter_id, $total_amount]);
            $order_id = $db->lastInsertId();

            // Insert order items
            foreach ($selected_items as $item_id) {
                $qty = (int)($quantities[$item_id] ?? 1);
                $stmt = $db->prepare("SELECT price FROM menu WHERE id = ?");
                $stmt->execute([$item_id]);
                $price = $stmt->fetchColumn();

                $insert_item = $db->prepare("
                    INSERT INTO order_items (order_id, menu_id, quantity, price)
                    VALUES (?, ?, ?, ?)
                ");
                $insert_item->execute([$order_id, $item_id, $qty, $price]);
            }

            // Assign to waiter
            $waiter_assign = $db->prepare("
                INSERT INTO waiter_orders (waiter_id, order_id, status, assigned_at)
                VALUES (?, ?, 'preparing', NOW())
            ");
            $waiter_assign->execute([$waiter_id, $order_id]);

            // Redirect to orders page
            header("Location: orders.php?success=1");
            exit;

        } catch (PDOException $e) {
            $message = 'Error placing order: ' . $e->getMessage();
            $message_type = 'danger';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Scan QR & Place Order - Mess Management</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
<style>
body { background: #f8f9fa; font-family: 'Poppins', sans-serif; padding-top: 60px; }
.btn-brand { background: #ff8c42; color: #fff; border:none; border-radius:8px; font-weight:500; }
.btn-brand:hover { background: #e6762f; color:#fff; }
.card { border-radius:12px; box-shadow:0 6px 18px rgba(0,0,0,0.04); }
</style>
</head>
<body>

<nav class="navbar navbar-dark bg-primary fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">Mess Management - Waiter</a>
    <div class="navbar-nav ms-auto d-flex flex-row gap-3">
      <a class="nav-link text-white" href="index.php">Dashboard</a>
      <a class="nav-link text-white" href="../../../logout.php">Logout</a>
    </div>
  </div>
</nav>

<div class="container mt-5 pt-4">
  <h4 class="mb-4"><i class="bi bi-qr-code-scan me-2"></i>Scan / Enter Table QR Code</h4>

  <?php if ($message): ?>
    <div class="alert alert-<?= $message_type ?>"><?= htmlspecialchars($message) ?></div>
  <?php endif; ?>

  <?php if (empty($menu_items)): ?>
  <!-- Scan / Enter Section -->
  <div class="card mb-4">
    <div class="card-header"><strong>Scan or Enter Table Code</strong></div>
    <div class="card-body">
      <form method="POST">
        <div class="input-group mb-3">
          <input type="text" name="qr_code" id="qrInput" class="form-control" placeholder="Enter or Scan Table QR" required>
          <button type="button" class="btn btn-outline-secondary" id="openCameraBtn"><i class="bi bi-camera"></i></button>
          <button type="submit" name="scan_qr" class="btn btn-brand">Enter</button>
        </div>
      </form>
    </div>
  </div>
  <?php endif; ?>

  <?php if (!empty($menu_items) && $table): ?>
  <!-- Menu Selection -->
  <div class="card">
    <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
      <span><i class="bi bi-list-ul me-2"></i>Menu for Table <?= htmlspecialchars($table['t_name']) ?></span>
      <a href="scan_qr.php" class="btn btn-light btn-sm">Change Table</a>
    </div>
    <div class="card-body">
      <form method="POST">
        <input type="hidden" name="place_order" value="1">
        <div class="table-responsive">
          <table class="table table-hover align-middle">
            <thead>
              <tr><th>Select</th><th>Item</th><th>Category</th><th>Price</th><th>Qty</th></tr>
            </thead>
            <tbody>
              <?php foreach ($menu_items as $item): ?>
              <tr>
                <td><input type="checkbox" name="items[]" value="<?= $item['id'] ?>"></td>
                <td><?= htmlspecialchars($item['name']) ?></td>
                <td><?= htmlspecialchars($item['category']) ?></td>
                <td>₹<?= number_format($item['price'], 2) ?></td>
                <td><input type="number" name="quantities[<?= $item['id'] ?>]" value="1" min="1" class="form-control form-control-sm" style="width:80px;"></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <div class="text-end mt-3">
          <button type="submit" class="btn btn-brand"><i class="bi bi-check-circle me-1"></i>Place Order</button>
        </div>
      </form>
    </div>
  </div>
  <?php endif; ?>
</div>

<!-- Camera Modal -->
<div class="modal fade" id="cameraModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title">Scan QR</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body text-center">
        <video id="cameraPreview" autoplay playsinline style="width:100%; border-radius:8px; background:#000;"></video>
        <canvas id="captureCanvas" style="display:none;"></canvas>
        <button class="btn btn-secondary w-100 mt-3" data-bs-dismiss="modal">Close Camera</button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jsqr/dist/jsQR.js"></script>

<script>
(() => {
  const openCameraBtn = document.getElementById('openCameraBtn');
  const qrInput = document.getElementById('qrInput');
  const modal = new bootstrap.Modal(document.getElementById('cameraModal'));
  const video = document.getElementById('cameraPreview');
  const canvas = document.getElementById('captureCanvas');
  const ctx = canvas.getContext('2d');
  let stream = null, scanning = false;

  async function startCamera() {
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      video.srcObject = stream;
      video.play();
      scanning = true;
      requestAnimationFrame(scanFrame);
    } catch (err) {
      alert('Camera access denied or unavailable.');
      modal.hide();
    }
  }

  function stopCamera() {
    scanning = false;
    if (stream) stream.getTracks().forEach(t => t.stop());
  }

  function scanFrame() {
    if (!scanning) return;
    if (video.readyState === video.HAVE_ENOUGH_DATA) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const code = jsQR(img.data, img.width, img.height);
      if (code) {
        qrInput.value = code.data.trim();
        stopCamera();
        modal.hide();
      }
    }
    if (scanning) requestAnimationFrame(scanFrame);
  }

  openCameraBtn?.addEventListener('click', () => { modal.show(); startCamera(); });
  document.getElementById('cameraModal')?.addEventListener('hidden.bs.modal', stopCamera);
})();
</script>
</body>
</html>
