<?php
// views/dashboard/waiter/support_order.php — Waiter Support / Create Order Page

if (session_status() === PHP_SESSION_NONE) session_start();

// Access control
if (empty($_SESSION['user_id']) || $_SESSION['role'] !== 'waiter') {
    header("Location: ../../auth/login.php");
    exit;
}

// --- Auto logout after 1 hour for guest/support mode ---
if (!empty($_SESSION['guest_mode']) && (time() - $_SESSION['guest_mode_start']) > 3600) {
    unset($_SESSION['guest_mode'], $_SESSION['guest_mode_start']);
    session_destroy();
    header("Location: ../../auth/login.php?timeout=1");
    exit;
}

require_once '../../../config/database.php';
$database = new Database();
$db = $database->getConnection();

$user_id   = $_SESSION['user_id'];
$user_name = $_SESSION['username'] ?? 'Waiter';
$success_message = '';
$error_message = '';

// ---- Fetch customers and menu items ----
$customers = $db->query("SELECT id, username FROM user ORDER BY username")->fetchAll(PDO::FETCH_ASSOC);
$menu_items = $db->query("SELECT id, description, category, menu_type FROM menu ORDER BY category, description")->fetchAll(PDO::FETCH_ASSOC);

// ---- Form submission ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $is_support   = isset($_POST['support_mode']);
    $table_name   = $_POST['table_name'] ?? '';
    $transaction_mode = $_POST['transaction_mode'] ?? 'Cash';
    $ordered_items = $_POST['ordered_items'] ?? [];
    $quantities    = $_POST['quantities'] ?? [];
    $customer_id   = $is_support ? null : ($_POST['customer_id'] ?? null);

    if (empty($table_name) || empty($ordered_items)) {
        $error_message = "Please fill all required fields.";
    } else {
        $order_desc = [];
        foreach ($ordered_items as $i => $item_id) {
            $qty = max(1, intval($quantities[$i] ?? 1));
            $desc = $db->prepare("SELECT description FROM menu WHERE id=?");
            $desc->execute([$item_id]);
            $item = $desc->fetchColumn();
            $order_desc[] = "$item (x$qty)";
        }
        $menu_text = implode(', ', $order_desc);

        try {
            $stmt = $db->prepare("
                INSERT INTO tabels (t_name, t_qr, t_s_w, time, transaction_mode, user_id, menu_ordered)
                VALUES (:t_name, :t_qr, 0, NOW(), :mode, :waiter, :menu)
            ");
            $t_qr = ord(strtoupper($table_name));
            $stmt->execute([
                ':t_name' => $table_name,
                ':t_qr'   => $t_qr,
                ':mode'   => $transaction_mode,
                ':waiter' => $user_id,
                ':menu'   => $menu_text
            ]);

            // Enable guest/support timer
            if ($is_support) {
                $_SESSION['guest_mode'] = true;
                $_SESSION['guest_mode_start'] = time();
            }

            $success_message = $is_support
                ? "Support order created successfully! Support mode active for 1 hour."
                : "Order placed successfully!";
        } catch (PDOException $e) {
            $error_message = "Database error while placing order.";
            error_log($e->getMessage());
        }
    }
}

ob_start();
?>
<div class="container-fluid py-3">
  <div class="page-title-box mb-3 d-flex justify-content-between align-items-center">
    <h4 class="page-title">Support / Create Order</h4>
    <a href="index.php" class="btn btn-sm btn-brand">
      <i class="bi bi-house me-1"></i> Back to Dashboard
    </a>
  </div>

  <?php if ($success_message): ?>
    <div class="alert alert-success"><?= htmlspecialchars($success_message) ?></div>
  <?php elseif ($error_message): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error_message) ?></div>
  <?php endif; ?>

  <form method="POST" class="card p-4 shadow-sm">
    <div class="form-check form-switch mb-3">
      <input class="form-check-input" type="checkbox" id="support_toggle" name="support_mode">
      <label class="form-check-label fw-medium" for="support_toggle">
        Enable Support Mode (Walk-In without Customer Account)
      </label>
    </div>

    <div id="customerFields">
      <div class="row mb-3">
        <div class="col-md-6">
          <label class="form-label">Select Customer</label>
          <select class="form-select" name="customer_id">
            <option value="">Select Customer...</option>
            <?php foreach ($customers as $c): ?>
              <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['username']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
    </div>

    <div class="row mb-3">
      <div class="col-md-6">
        <label class="form-label">Table Name</label>
        <select class="form-select" name="table_name" required>
          <option value="">Select Table</option>
          <?php foreach (range('A', 'J') as $t): ?>
            <option value="<?= $t ?>">Table <?= $t ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-6">
        <label class="form-label">Transaction Mode</label>
        <select class="form-select" name="transaction_mode">
          <option value="Cash">Cash</option>
          <option value="Card">Card</option>
          <option value="UPI">UPI</option>
        </select>
      </div>
    </div>

    <h5 class="fw-semibold mb-2">Menu Items</h5>
    <div class="row g-2">
      <?php foreach ($menu_items as $m): ?>
        <div class="col-md-4">
          <div class="form-check border rounded p-2">
            <input class="form-check-input" type="checkbox" name="ordered_items[]" value="<?= $m['id'] ?>" id="item<?= $m['id'] ?>" onchange="toggleQty(<?= $m['id'] ?>)">
            <label class="form-check-label" for="item<?= $m['id'] ?>">
              <?= htmlspecialchars($m['description']) ?> 
              <span class="badge <?= $m['menu_type']=='Veg'?'bg-success':'bg-danger' ?>"><?= $m['menu_type'] ?></span>
            </label>
            <input type="number" name="quantities[]" id="qty<?= $m['id'] ?>" class="form-control form-control-sm mt-1 d-none" value="1" min="1" style="width:80px;">
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="mt-4 text-end">
      <button class="btn btn-brand px-4">
        <i class="bi bi-check2-circle me-1"></i> Place Order
      </button>
    </div>
  </form>
</div>

<script>
document.getElementById('support_toggle').addEventListener('change', e => {
  document.getElementById('customerFields').style.display = e.target.checked ? 'none' : 'block';
});
function toggleQty(id){
  const q = document.getElementById('qty'+id);
  q.classList.toggle('d-none');
}
</script>

<?php
$content = ob_get_clean();
include '../../layouts/app.php';
?>
