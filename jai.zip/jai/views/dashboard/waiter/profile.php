<?php
// Waiter Profile (Unified Page - View + Update + Change Password)
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'waiter') {
    header("Location: ../../auth/login.php");
    exit;
}

require_once '../../../config/database.php';
$database = new Database();
$db = $database->getConnection();

$user_id   = $_SESSION['user_id'];
$user_name = $_SESSION['username'] ?? 'Waiter';
$message   = "";

// ✅ Handle Profile Update
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['update_profile'])) {
    $first_name = trim($_POST['first_name']);
    $last_name  = trim($_POST['last_name']);
    $email      = trim($_POST['email']);
    $phone      = trim($_POST['ph_no']);
    $gender     = $_POST['gender'] ?? null;

    // Handle Profile Image
    $profile_image = null;
    if (!empty($_FILES['profile_image']['name'])) {
        $upload_dir = realpath(__DIR__ . '/../../../uploads/');
        if (!$upload_dir || !is_dir($upload_dir)) {
            mkdir(__DIR__ . '/../../../uploads', 0777, true);
            $upload_dir = realpath(__DIR__ . '/../../../uploads/');
        }

        $filename = time() . "_" . preg_replace("/[^a-zA-Z0-9._-]/", "_", $_FILES["profile_image"]["name"]);
        $target_file = $upload_dir . DIRECTORY_SEPARATOR . $filename;

        if (move_uploaded_file($_FILES["profile_image"]["tmp_name"], $target_file)) {
            $profile_image = $filename;
        }
    }

    $sql = "UPDATE user SET first_name = :first_name, last_name = :last_name, email = :email, ph_no = :ph_no, gender = :gender";
    if ($profile_image) $sql .= ", profile_image = :profile_image";
    $sql .= " WHERE id = :id";

    $stmt = $db->prepare($sql);
    $stmt->bindParam(':first_name', $first_name);
    $stmt->bindParam(':last_name', $last_name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':ph_no', $phone);
    $stmt->bindParam(':gender', $gender);
    if ($profile_image) $stmt->bindParam(':profile_image', $profile_image);
    $stmt->bindParam(':id', $user_id);

    if ($stmt->execute()) {
        $message = "<div class='alert alert-success'>Profile updated successfully!</div>";
    } else {
        $message = "<div class='alert alert-danger'>Error updating profile.</div>";
    }
}

// ✅ Handle Password Update
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['update_password'])) {
    $old_pass = $_POST['old_password'];
    $new_pass = $_POST['new_password'];
    $confirm_pass = $_POST['confirm_password'];

    $stmt = $db->prepare("SELECT password FROM user WHERE id = :id");
    $stmt->bindParam(':id', $user_id);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row && password_verify($old_pass, $row['password'])) {
        if ($new_pass === $confirm_pass) {
            $new_hash = password_hash($new_pass, PASSWORD_BCRYPT);
            $update = $db->prepare("UPDATE user SET password = :password WHERE id = :id");
            $update->bindParam(':password', $new_hash);
            $update->bindParam(':id', $user_id);
            $update->execute();
            $message = "<div class='alert alert-success'>Password updated successfully!</div>";
        } else {
            $message = "<div class='alert alert-warning'>New passwords do not match.</div>";
        }
    } else {
        $message = "<div class='alert alert-danger'>Incorrect old password.</div>";
    }
}

// ✅ Fetch Waiter Info
$stmt = $db->prepare("SELECT * FROM user WHERE id = :id");
$stmt->bindParam(':id', $user_id);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$profile_image_url = !empty($user['profile_image'])
    ? "../../../uploads/" . htmlspecialchars($user['profile_image'])
    : "https://cdn-icons-png.flaticon.com/512/847/847969.png";

ob_start();
?>

<style>
.profile-avatar {
  width: 120px; height: 120px;
  border-radius: 50%;
  object-fit: cover;
  border: 3px solid #ff8c42;
}
.profile-section .card {
  border-radius: 14px;
  box-shadow: 0 6px 18px rgba(0,0,0,0.05);
  border: none;
}
.btn-brand {
  background-color: #ff8c42;
  color: #fff;
  border-radius: 8px;
}
.btn-brand:hover {
  background-color: #e6762f;
  color: #fff;
}
</style>

<div class="container-fluid profile-section py-3">
  <?= $message ?>

  <div class="page-title-box mb-4 d-flex justify-content-between align-items-center">
    <h4 class="page-title">My Profile</h4>
    <a href="index.php" class="btn btn-sm btn-brand"><i class="bi bi-house me-1"></i> Dashboard</a>
  </div>

  <div class="row g-4">
    <!-- Profile Overview -->
    <div class="col-lg-4">
      <div class="card text-center p-4">
        <img src="<?= $profile_image_url ?>" id="profilePreview" class="profile-avatar mx-auto mb-3" alt="Profile Picture">
        <h5 class="fw-semibold mb-0"><?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></h5>
        <p class="text-muted mb-2"><?= htmlspecialchars($user['email']); ?></p>
        <span class="badge bg-success mb-2"><?= ucfirst($user['role']); ?></span>
        <div>
          <small class="text-muted">Member since <?= date('M Y', strtotime($user['created_at'])); ?></small>
        </div>
      </div>
    </div>

    <!-- Profile Update -->
    <div class="col-lg-8">
      <div class="card">
        <div class="card-header bg-white fw-bold"><i class="bi bi-pencil-square me-2 text-warning"></i> Update Profile</div>
        <div class="card-body">
          <form method="POST" enctype="multipart/form-data">
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label">First Name</label>
                <input type="text" name="first_name" value="<?= htmlspecialchars($user['first_name']); ?>" class="form-control" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">Last Name</label>
                <input type="text" name="last_name" value="<?= htmlspecialchars($user['last_name']); ?>" class="form-control" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">Email</label>
                <input type="email" name="email" value="<?= htmlspecialchars($user['email']); ?>" class="form-control" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">Phone</label>
                <input type="text" name="ph_no" value="<?= htmlspecialchars($user['ph_no']); ?>" class="form-control">
              </div>
              <div class="col-md-6">
                <label class="form-label">Gender</label>
                <select name="gender" class="form-select">
                  <option value="">Select</option>
                  <option value="Male" <?= $user['gender'] === 'Male' ? 'selected' : '' ?>>Male</option>
                  <option value="Female" <?= $user['gender'] === 'Female' ? 'selected' : '' ?>>Female</option>
                  <option value="Other" <?= $user['gender'] === 'Other' ? 'selected' : '' ?>>Other</option>
                </select>
              </div>
              <div class="col-md-6">
                <label class="form-label">Profile Picture</label>
                <input type="file" name="profile_image" id="profileImageInput" class="form-control">
              </div>
            </div>
            <div class="text-end mt-3">
              <button type="submit" name="update_profile" class="btn btn-brand"><i class="bi bi-save me-1"></i> Save Changes</button>
            </div>
          </form>
        </div>
      </div>

      <!-- Password Update -->
      <div class="card mt-4">
        <div class="card-header bg-white fw-bold"><i class="bi bi-key me-2 text-warning"></i> Change Password</div>
        <div class="card-body">
          <form method="POST">
            <div class="row g-3">
              <div class="col-md-4">
                <label class="form-label">Old Password</label>
                <input type="password" name="old_password" class="form-control" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">New Password</label>
                <input type="password" name="new_password" class="form-control" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control" required>
              </div>
            </div>
            <div class="text-end mt-3">
              <button type="submit" name="update_password" class="btn btn-warning text-white">
                <i class="bi bi-shield-lock me-1"></i> Update Password
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ✅ Live Image Preview -->
<script>
document.getElementById("profileImageInput").addEventListener("change", function(e) {
  const file = e.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = (event) => {
      document.getElementById("profilePreview").src = event.target.result;
    };
    reader.readAsDataURL(file);
  }
});
</script>

<?php
$content = ob_get_clean();
include '../../layouts/app.php';
?>
