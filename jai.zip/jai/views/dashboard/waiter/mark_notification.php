<?php
// views/dashboard/waiter/mark_notification.php

if (session_status() === PHP_SESSION_NONE) session_start();

if (empty($_SESSION['user_id']) || $_SESSION['role'] !== 'waiter') {
    http_response_code(403);
    exit('Access denied');
}

require_once '../../../config/database.php';
$database = new Database();
$db = $database->getConnection();

$id = $_POST['id'] ?? null;

if ($id) {
    try {
        $stmt = $db->prepare("UPDATE notifications SET is_read = 1 WHERE id = :id");
        $stmt->execute([':id' => $id]);
    } catch (PDOException $e) {
        error_log("Mark notification read error: " . $e->getMessage());
    }
}
?>
