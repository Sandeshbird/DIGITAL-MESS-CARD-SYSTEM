<?php
// views/dashboard/waiter/fetch_notifications.php

if (session_status() === PHP_SESSION_NONE) session_start();

// ✅ Access control
if (empty($_SESSION['user_id']) || $_SESSION['role'] !== 'waiter') {
    http_response_code(403);
    exit('Access denied');
}

require_once '../../../config/database.php';
$database = new Database();
$db = $database->getConnection();

$user_id = $_SESSION['user_id'];

try {
    $stmt = $db->prepare("
        SELECT id, title, message, created_at 
        FROM notifications
        WHERE waiter_id = :waiter_id AND is_read = 0
        ORDER BY created_at DESC
        LIMIT 5
    ");
    $stmt->execute([':waiter_id' => $user_id]);
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($notifications) {
        foreach ($notifications as $n) {
            echo '
            <div class="toast align-items-center text-bg-light border-0 mb-2" role="alert" aria-live="assertive" aria-atomic="true" data-id="'.$n['id'].'">
                <div class="d-flex">
                    <div class="toast-body">
                        <strong class="text-dark">'.htmlspecialchars($n['title']).'</strong><br>
                        <span class="text-muted small">'.htmlspecialchars($n['message']).'</span>
                    </div>
                    <button type="button" class="btn-close me-2 m-auto" aria-label="Close" onclick="markAsRead('.$n['id'].')"></button>
                </div>
            </div>';
        }
    }
} catch (PDOException $e) {
    error_log("Fetch notifications error: " . $e->getMessage());
}
?>
