<?php
// views/dashboard/waiter/orders.php — Waiter Orders Management (no Create Order button)

if (session_status() === PHP_SESSION_NONE) session_start();

// ✅ Restrict access
if (empty($_SESSION['user_id']) || $_SESSION['role'] !== 'waiter') {
    header("Location: ../../auth/login.php");
    exit;
}

// ✅ Auto logout after 1 hour in guest/support mode
if (!empty($_SESSION['guest_mode']) && (time() - $_SESSION['guest_mode_start']) > 3600) {
    unset($_SESSION['guest_mode'], $_SESSION['guest_mode_start']);
    session_destroy();
    header("Location: ../../auth/login.php?timeout=1");
    exit;
}

$user_id    = $_SESSION['user_id'];
$user_name  = $_SESSION['username'] ?? 'Waiter';
$guest_mode = !empty($_SESSION['guest_mode']);

require_once '../../../config/database.php';
$database = new Database();
$db = $database->getConnection();

/* ---- Fetch Orders ---- */
function fetchOrders($db, $user_id, $status) {
    $sql = "
      SELECT wo.*, o.*, t.t_name, u.username
      FROM waiter_orders wo
      JOIN orders o ON wo.order_id = o.id
      JOIN tables t ON o.table_id = t.id
      JOIN user u ON o.user_id = u.id
      WHERE wo.waiter_id = ? AND wo.status = ?
      ORDER BY wo.assigned_at DESC
    ";
    $stmt = $db->prepare($sql);
    $stmt->execute([$user_id, $status]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$assigned_orders  = fetchOrders($db, $user_id, 'preparing');
$completed_orders = fetchOrders($db, $user_id, 'served');
$cancelled_orders = fetchOrders($db, $user_id, 'cancelled');

ob_start();
?>
<style>
:root {
  --brand: #ff8c42;
  --brand-dark: #e6762f;
}
.btn-brand {
  background: var(--brand);
  border: none;
  color: #fff;
  border-radius: 8px;
  transition: all .2s;
}
.btn-brand:hover { background: var(--brand-dark); color:#fff; }
.timer-alert {
  background: #fff3cd;
  border-left: 4px solid #ffcc00;
  padding: .75rem 1rem;
  border-radius: 8px;
  margin-bottom: 1rem;
}
.page-title-box h4 { font-weight: 600; }
</style>

<div class="container-fluid">
  <!-- Page Header -->
  <div class="page-title-box d-flex align-items-center justify-content-between flex-wrap">
    <h4 class="page-title mb-2">
      <?= $guest_mode ? 'Support Mode — Active' : 'Manage Orders'; ?>
    </h4>
    <div class="text-end mb-2">
      <a href="index.php" class="btn btn-sm btn-brand">
        <i class="bi bi-house me-1"></i> Dashboard
      </a>
    </div>
  </div>

  <!-- Support Timer -->
  <?php if ($guest_mode): ?>
    <?php
      $remaining = 3600 - (time() - $_SESSION['guest_mode_start']);
      $minutes = floor($remaining / 60);
    ?>
    <div class="timer-alert">
      <i class="bi bi-hourglass-split me-2"></i>
      Support session expires in <strong><?= $minutes ?> min</strong>.
      You’ll be logged out automatically afterward.
    </div>
  <?php endif; ?>

  <!-- Tabs -->
  <ul class="nav nav-tabs mt-3" id="orderTabs" role="tablist">
    <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#assigned" type="button">Active Orders</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#completed" type="button">Completed</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#cancelled" type="button">Cancelled</button></li>
  </ul>

  <div class="tab-content pt-3">
    <!-- Active Orders -->
    <div class="tab-pane fade show active" id="assigned">
      <?php if (empty($assigned_orders)): ?>
        <div class="text-center py-5">
          <i class="bi bi-list-check" style="font-size:3rem;color:#ccc;"></i>
          <h5 class="mt-3 mb-1">No Active Orders</h5>
          <p class="text-muted">Orders will appear here when assigned.</p>
        </div>
      <?php else: ?>
        <div class="table-responsive">
          <table class="table table-hover align-middle">
            <thead>
              <tr>
                <th>Table</th><th>User</th><th>Amount</th><th>Status</th><th>Assigned</th><th class="text-end">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($assigned_orders as $order): ?>
              <tr>
                <td><strong><?= htmlspecialchars($order['t_name']); ?></strong></td>
                <td><?= htmlspecialchars($order['username']); ?></td>
                <td>₹<?= number_format($order['total_amount'],2); ?></td>
                <td><span class="badge bg-warning text-dark"><?= ucfirst($order['status']); ?></span></td>
                <td><?= date('h:i A', strtotime($order['assigned_at'])); ?></td>
                <td class="text-end">
                  <a href="update.php?id=<?= $order['order_id']; ?>&action=serve" class="btn btn-success btn-sm">
                    <i class="bi bi-check2-circle"></i>
                  </a>
                  <form method="POST" action="delete.php" class="d-inline">
                    <input type="hidden" name="order_id" value="<?= $order['order_id']; ?>">
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Cancel this order?')">
                      <i class="bi bi-trash"></i>
                    </button>
                  </form>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>

    <!-- Completed Orders -->
    <div class="tab-pane fade" id="completed">
      <?php if (empty($completed_orders)): ?>
        <p class="text-center py-4 text-muted">No completed orders yet.</p>
      <?php else: ?>
        <div class="table-responsive">
          <table class="table table-hover align-middle">
            <thead><tr><th>Table</th><th>User</th><th>Amount</th><th>Served At</th></tr></thead>
            <tbody>
              <?php foreach ($completed_orders as $order): ?>
              <tr>
                <td><?= htmlspecialchars($order['t_name']); ?></td>
                <td><?= htmlspecialchars($order['username']); ?></td>
                <td>₹<?= number_format($order['total_amount'],2); ?></td>
                <td><?= date('M d, Y h:i A', strtotime($order['served_at'])); ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>

    <!-- Cancelled Orders -->
    <div class="tab-pane fade" id="cancelled">
      <?php if (empty($cancelled_orders)): ?>
        <p class="text-center py-4 text-muted">No cancelled orders.</p>
      <?php else: ?>
        <div class="table-responsive">
          <table class="table table-hover align-middle">
            <thead><tr><th>Table</th><th>User</th><th>Amount</th><th>Cancelled At</th></tr></thead>
            <tbody>
              <?php foreach ($cancelled_orders as $order): ?>
              <tr>
                <td><?= htmlspecialchars($order['t_name']); ?></td>
                <td><?= htmlspecialchars($order['username']); ?></td>
                <td>₹<?= number_format($order['total_amount'],2); ?></td>
                <td><?= date('M d, Y h:i A', strtotime($order['served_at'] ?? $order['assigned_at'])); ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <div class="card mt-4">
    <div class="card-header"><i class="bi bi-info-circle me-2 text-muted"></i><strong>Order Instructions</strong></div>
    <div class="card-body">
      <ul>
        <li><strong>Serve Order:</strong> Click ✅ when served.</li>
        <li><strong>Cancel Order:</strong> 🗑 deletes or cancels.</li>
        <li><strong>Create / Support:</strong> Use the sidebar “Create / Support Order” page.</li>
        <li><strong>Auto Logout:</strong> Support mode ends after 1 hour.</li>
        <li><strong>Back to Dashboard:</strong> Use the orange “Dashboard” button anytime.</li>
      </ul>
    </div>
  </div>
</div>

<?php
$content = ob_get_clean();
include '../../layouts/app.php';
?>
