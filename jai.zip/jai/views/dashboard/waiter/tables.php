<?php
// views/dashboard/waiter/tables.php — Waiter Table Management (Enhanced + Delete & Add)

if (session_status() === PHP_SESSION_NONE) session_start();
if (empty($_SESSION['user_id']) || $_SESSION['role'] !== 'waiter') {
    header("Location: ../../auth/login.php");
    exit;
}

require_once '../../../config/database.php';
$database = new Database();
$db = $database->getConnection();

$user_name = $_SESSION['username'] ?? 'Waiter';
$message = '';
$message_type = '';

// ✅ Handle Delete Table
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $delete_id = intval($_POST['delete_id']);
    try {
        $stmt = $db->prepare("DELETE FROM tables WHERE id = ?");
        $stmt->execute([$delete_id]);
        $message = "Table deleted successfully.";
        $message_type = "success";
    } catch (PDOException $e) {
        $message = "Failed to delete table.";
        $message_type = "danger";
        error_log("Delete table error: " . $e->getMessage());
    }
}

// ✅ Handle Add Table (optional quick feature)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_table'])) {
    $t_name = trim($_POST['t_name']);
    if (!empty($t_name)) {
        try {
            $qr_code = 'QR-' . strtoupper(substr(md5(uniqid()), 0, 6));
            $stmt = $db->prepare("INSERT INTO tables (t_name, t_qr, status, created_at) VALUES (?, ?, 'available', NOW())");
            $stmt->execute([$t_name, $qr_code]);
            $message = "New table added successfully.";
            $message_type = "success";
        } catch (PDOException $e) {
            $message = "Failed to add table.";
            $message_type = "danger";
        }
    } else {
        $message = "Table name cannot be empty.";
        $message_type = "warning";
    }
}

// ✅ Fetch all tables
$tables = [];
try {
    $stmt = $db->prepare("SELECT * FROM tables ORDER BY t_name ASC");
    $stmt->execute();
    $tables = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching tables: " . $e->getMessage());
}

// ✅ Count by status
$available_count = $occupied_count = $reserved_count = 0;
foreach ($tables as $table) {
    if ($table['status'] === 'available') $available_count++;
    elseif ($table['status'] === 'occupied') $occupied_count++;
    elseif ($table['status'] === 'reserved') $reserved_count++;
}

ob_start();
?>

<style>
:root {
  --brand: #ff8c42;
  --brand-dark: #e6762f;
}
.btn-brand {
  background: var(--brand);
  border: none;
  color: #fff;
  border-radius: 8px;
  transition: 0.2s;
}
.btn-brand:hover { background: var(--brand-dark); color: #fff; }
.stat-card { border-radius: 14px; padding: 1.5rem; color: #fff; text-align: center; }
.stat-available { background: linear-gradient(45deg,#45c17a,#3aa46d); }
.stat-occupied { background: linear-gradient(45deg,#ffb26b,#f2a75a); }
.stat-reserved { background: linear-gradient(45deg,#8b6ddf,#6f42c1); }
.table-hover tbody tr:hover { background: rgba(255,140,66,0.07); }
</style>

<div class="container-fluid">

  <!-- Title -->
  <div class="page-title-box d-flex align-items-center justify-content-between">
    <h4 class="page-title mb-0">Table Management</h4>
    <a href="index.php" class="btn btn-sm btn-brand"><i class="bi bi-house me-1"></i> Dashboard</a>
  </div>

  <!-- Alerts -->
  <?php if (!empty($message)): ?>
    <div class="alert alert-<?= $message_type ?> alert-dismissible fade show mt-2">
      <?= htmlspecialchars($message) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <!-- Stats -->
  <div class="row g-3 mb-4">
    <div class="col-md-4"><div class="stat-card stat-available"><i class="bi bi-grid"></i><h3><?= $available_count ?></h3><small>Available</small></div></div>
    <div class="col-md-4"><div class="stat-card stat-occupied"><i class="bi bi-people-fill"></i><h3><?= $occupied_count ?></h3><small>Occupied</small></div></div>
    <div class="col-md-4"><div class="stat-card stat-reserved"><i class="bi bi-bookmark-check"></i><h3><?= $reserved_count ?></h3><small>Reserved</small></div></div>
  </div>

  <!-- Add Table -->
  <div class="card mb-4 shadow-sm">
    <div class="card-header fw-bold d-flex justify-content-between align-items-center">
      <span><i class="bi bi-plus-circle me-2 text-warning"></i>Add New Table</span>
    </div>
    <div class="card-body">
      <form method="POST" class="d-flex gap-2 align-items-center">
        <input type="text" name="t_name" class="form-control w-auto" placeholder="Table name (e.g. T5)" required>
        <button type="submit" name="add_table" class="btn btn-success">
          <i class="bi bi-check2-circle me-1"></i> Add
        </button>
      </form>
    </div>
  </div>

  <!-- Tables List -->
  <div class="card mb-4 shadow-sm">
    <div class="card-header d-flex justify-content-between align-items-center">
      <h5 class="mb-0"><i class="bi bi-table me-2 text-muted"></i>All Tables</h5>
      <span class="badge bg-warning text-dark"><?= count($tables) ?> Total</span>
    </div>
    <div class="card-body">
      <?php if (empty($tables)): ?>
        <div class="text-center py-5">
          <i class="bi bi-table" style="font-size:3rem;color:#ccc;"></i>
          <h5 class="mt-3 mb-1">No Tables Found</h5>
          <p class="text-muted">Tables will appear here once added.</p>
        </div>
      <?php else: ?>
        <div class="table-responsive">
          <table class="table table-hover align-middle">
            <thead>
              <tr>
                <th>QR Code</th>
                <th>Table</th>
                <th>Status</th>
                <th>Created</th>
                <th class="text-end">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($tables as $t): ?>
                <tr>
                  <td><?= htmlspecialchars($t['t_qr']); ?></td>
                  <td><strong><?= htmlspecialchars($t['t_name']); ?></strong></td>
                  <td>
                    <?php if ($t['status'] === 'available'): ?>
                      <span class="badge bg-success">Available</span>
                    <?php elseif ($t['status'] === 'occupied'): ?>
                      <span class="badge bg-warning text-dark">Occupied</span>
                    <?php elseif ($t['status'] === 'reserved'): ?>
                      <span class="badge bg-info text-dark">Reserved</span>
                    <?php else: ?>
                      <span class="badge bg-secondary">Unknown</span>
                    <?php endif; ?>
                  </td>
                  <td><?= date('M d, Y h:i A', strtotime($t['created_at'])); ?></td>
                  <td class="text-end">
                    <form method="POST" class="d-inline">
                      <input type="hidden" name="delete_id" value="<?= $t['id']; ?>">
                      <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Delete this table?');">
                        <i class="bi bi-trash"></i>
                      </button>
                    </form>
                    <a href="view_qr.php?id=<?= $t['id'] ?>" class="btn btn-outline-secondary btn-sm">
                      <i class="bi bi-qr-code"></i>
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Guide -->
  <div class="card">
    <div class="card-header fw-bold"><i class="bi bi-info-circle me-2 text-muted"></i>Status Guide</div>
    <div class="card-body small">
      <p><span class="badge bg-success">Available</span> = Table ready for new customers</p>
      <p><span class="badge bg-warning text-dark">Occupied</span> = Table in use</p>
      <p><span class="badge bg-info text-dark">Reserved</span> = Reserved for later</p>
      <p class="mb-0 text-muted">Status updates automatically when orders complete or cancel.</p>
    </div>
  </div>
</div>

<?php
$content = ob_get_clean();
include '../../layouts/app.php';
?>
