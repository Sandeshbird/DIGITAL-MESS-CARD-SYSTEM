<?php
// views/dashboard/waiter/select_menu.php — Waiter selects menu items (connected to admin/menu.php)

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'waiter') {
    header("Location: ../../auth/login.php");
    exit;
}

require_once '../../../config/database.php';
$database = new Database();
$db = $database->getConnection();

$waiter_id = $_SESSION['user_id'];
$waiter_name = $_SESSION['username'] ?? 'Waiter';

if (!isset($_SESSION['order_user_id'])) {
    header("Location: scan_qr.php");
    exit;
}

$order_user_id   = $_SESSION['order_user_id'];
$order_user_name = $_SESSION['order_user_name'] ?? 'User';
$message = '';
$message_type = '';

try {
    // ✅ Fetch menu from same table admin updates
    $menu_stmt = $db->prepare("SELECT id, menu_type, category, description, price FROM menu ORDER BY category, description");
    $menu_stmt->execute();
    $menu_items = $menu_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $menu_items = [];
    error_log("Menu fetch error: " . $e->getMessage());
}

// Group menu by category
$menu_by_category = [];
foreach ($menu_items as $item) {
    $menu_by_category[$item['category']][] = $item;
}

// ✅ Handle order submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['select_menu'])) {
    $selected_items = $_POST['items'] ?? [];
    $quantities = $_POST['quantities'] ?? [];

    if (empty($selected_items)) {
        $message = 'Please select at least one menu item.';
        $message_type = 'danger';
    } else {
        try {
            $total_amount = 0;

            foreach ($selected_items as $item_id) {
                $quantity = max(1, (int)($quantities[$item_id] ?? 1));
                foreach ($menu_items as $item) {
                    if ($item['id'] == $item_id) {
                        $total_amount += $item['price'] * $quantity;
                        break;
                    }
                }
            }

            // ✅ Insert order
            $order_stmt = $db->prepare("INSERT INTO orders (table_id, user_id, total_amount, status, order_time) VALUES (?, ?, ?, 'pending', NOW())");
            $order_stmt->execute([1, $order_user_id, $total_amount]);
            $order_id = $db->lastInsertId();

            // ✅ Insert each ordered item
            foreach ($selected_items as $item_id) {
                $quantity = max(1, (int)($quantities[$item_id] ?? 1));
                foreach ($menu_items as $item) {
                    if ($item['id'] == $item_id) {
                        $item_stmt = $db->prepare("INSERT INTO order_items (order_id, menu_id, quantity, price) VALUES (?, ?, ?, ?)");
                        $item_stmt->execute([$order_id, $item_id, $quantity, $item['price']]);
                        break;
                    }
                }
            }

            // ✅ Assign to waiter
            $assign_stmt = $db->prepare("INSERT INTO waiter_orders (waiter_id, order_id, status, assigned_at) VALUES (?, ?, 'preparing', NOW())");
            $assign_stmt->execute([$waiter_id, $order_id]);

            // ✅ Add notification
            $notify_stmt = $db->prepare("INSERT INTO notifications (waiter_id, title, message) VALUES (?, ?, ?)");
            $notify_stmt->execute([
                $waiter_id,
                '🍽️ Order Placed Successfully',
                'Order #' . $order_id . ' placed by ' . $order_user_name . ' (Total ₹' . number_format($total_amount, 2) . ')'
            ]);

            unset($_SESSION['order_user_id'], $_SESSION['order_user_name']);
            $message = "Order placed successfully! Order ID: " . $order_id;
            $message_type = "success";

        } catch (PDOException $e) {
            $message = 'Error placing order.';
            $message_type = 'danger';
            error_log("Order insert error: " . $e->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Select Menu - Mess Management</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
<style>
body { background: #f7f7f7; }
.card { border: none; box-shadow: 0 3px 10px rgba(0,0,0,0.1); }
.btn-add { background: #ff8c42; color: #fff; border: none; }
.btn-add:hover { background: #e6762f; color: #fff; }
</style>
</head>
<body>

<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Select Menu for <?= htmlspecialchars($order_user_name) ?></h4>
    <a href="scan_qr.php" class="btn btn-secondary btn-sm"><i class="bi bi-arrow-left"></i> Back</a>
  </div>

  <?php if ($message): ?>
    <div class="alert alert-<?= $message_type ?>"><?= htmlspecialchars($message) ?></div>
  <?php endif; ?>

  <form method="POST" id="menuForm">
    <div class="accordion" id="menuAccordion">
      <?php foreach ($menu_by_category as $category => $items): ?>
        <?php $cat_id = strtolower(str_replace(' ', '-', $category)); ?>
        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#<?= $cat_id ?>">
              <?= htmlspecialchars($category) ?>
            </button>
          </h2>
          <div id="<?= $cat_id ?>" class="accordion-collapse collapse">
            <div class="accordion-body">
              <table class="table table-hover table-sm align-middle">
                <thead>
                  <tr><th></th><th>Description</th><th>Type</th><th>Qty</th><th>Price</th></tr>
                </thead>
                <tbody>
                <?php foreach ($items as $item): ?>
                  <tr>
                    <td><input type="checkbox" name="items[]" value="<?= $item['id'] ?>" class="menu-check"></td>
                    <td><?= htmlspecialchars($item['description']) ?></td>
                    <td><?= htmlspecialchars($item['menu_type']) ?></td>
                    <td><input type="number" name="quantities[<?= $item['id'] ?>]" value="1" min="1" class="form-control form-control-sm quantity" style="width:80px"></td>
                    <td>₹<?= number_format($item['price'], 2) ?></td>
                  </tr>
                <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="mt-4 d-flex justify-content-between align-items-center">
      <div>
        <button type="submit" name="select_menu" class="btn btn-success"><i class="bi bi-check-circle me-1"></i> Place Order</button>
        <button type="button" id="addItemBtn" class="btn btn-add ms-2"><i class="bi bi-plus-circle"></i> Add Item</button>
      </div>
      <h5 class="mb-0">Total: ₹<span id="totalPrice">0.00</span></h5>
    </div>
  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// === Dynamic Total Calculation ===
function updateTotal() {
  let total = 0;
  document.querySelectorAll('input.menu-check:checked').forEach(checkbox => {
    const row = checkbox.closest('tr');
    const qty = parseFloat(row.querySelector('.quantity').value) || 1;
    const priceText = row.cells[4].innerText.replace('₹', '');
    const price = parseFloat(priceText) || 0;
    total += qty * price;
  });
  document.getElementById('totalPrice').textContent = total.toFixed(2);
}
document.querySelectorAll('.menu-check, .quantity').forEach(el => el.addEventListener('input', updateTotal));

// === Add Item button triggers Admin connection (optional popup link) ===
document.getElementById('addItemBtn').addEventListener('click', () => {
  window.open('../../admin/menu.php', '_blank');
});
</script>
</body>
</html>
