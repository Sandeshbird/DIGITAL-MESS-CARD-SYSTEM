<?php
// views/dashboard/waiter/view_qr.php — View & Regenerate Table QR Code

if (session_status() === PHP_SESSION_NONE) session_start();
if (empty($_SESSION['user_id']) || $_SESSION['role'] !== 'waiter') {
    header("Location: ../../auth/login.php");
    exit;
}

require_once '../../../config/database.php';
$database = new Database();
$db = $database->getConnection();

if (!isset($_GET['id'])) {
    echo "<div class='alert alert-danger m-4'>Table ID missing.</div>";
    exit;
}

$table_id = intval($_GET['id']);

// ✅ Handle QR Regeneration
if (isset($_POST['regenerate_qr'])) {
    $new_qr = 'TEMP_' . strtoupper(bin2hex(random_bytes(3)));
    $stmt = $db->prepare("UPDATE tables SET t_qr = ? WHERE id = ?");
    $stmt->execute([$new_qr, $table_id]);
    $message = "QR Code regenerated successfully!";
    header("Location: view_qr.php?id={$table_id}&msg=" . urlencode($message));
    exit;
}

// ✅ Fetch Table Info
$stmt = $db->prepare("SELECT * FROM tables WHERE id = ?");
$stmt->execute([$table_id]);
$table = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$table) {
    echo "<div class='alert alert-danger m-4'>Invalid Table ID.</div>";
    exit;
}

$table_name = htmlspecialchars($table['t_name']);
$table_qr   = htmlspecialchars($table['t_qr']);
$qr_text    = urlencode("https://yourdomain.com/scan.php?table=" . $table_qr);

$message = $_GET['msg'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>QR - <?= $table_name ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
body {
  background: #f9fafc;
  font-family: 'Poppins', sans-serif;
}
.qr-box {
  max-width: 420px;
  margin: 5rem auto;
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 8px 24px rgba(0,0,0,0.08);
  text-align: center;
  padding: 2rem;
}
.qr-box img {
  border: 8px solid #ff8c42;
  border-radius: 12px;
  margin: 1rem 0;
}
.btn-brand {
  background: #ff8c42;
  color: #fff;
  border: none;
  border-radius: 8px;
}
.btn-brand:hover { background: #e6762f; color: #fff; }
.alert {
  max-width: 400px;
  margin: 2rem auto;
}
</style>
</head>
<body>

<?php if ($message): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
  <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($message) ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="qr-box">
  <h4 class="fw-bold text-dark mb-3">Table <?= $table_name ?></h4>
  <p class="text-muted small mb-1">QR Code Identifier:</p>
  <p class="fw-semibold text-secondary mb-3"><?= $table_qr ?></p>

  <img src="https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl=<?= $qr_text ?>&choe=UTF-8" alt="QR Code">

  <div class="mt-4 d-flex justify-content-center flex-wrap gap-2">
    <a href="tables.php" class="btn btn-brand"><i class="bi bi-arrow-left"></i> Back</a>
    <button onclick="window.print();" class="btn btn-outline-secondary"><i class="bi bi-printer"></i> Print</button>

    <form method="POST" onsubmit="return confirm('Regenerate a new QR for this table?');">
      <button type="submit" name="regenerate_qr" class="btn btn-danger">
        <i class="bi bi-arrow-repeat"></i> Regenerate QR
      </button>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
