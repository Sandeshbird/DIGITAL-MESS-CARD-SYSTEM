<?php
// views/dashboard/waiter/index.php — Waiter Dashboard (Integrated with Scan QR Page)

if (session_status() === PHP_SESSION_NONE) session_start();

// Restrict access to waiters only
if (empty($_SESSION['user_id']) || $_SESSION['role'] !== 'waiter') {
    header("Location: ../../auth/login.php");
    exit;
}

require_once '../../../config/database.php';
$database = new Database();
$db = $database->getConnection();

$user_id   = $_SESSION['user_id'];
$user_name = $_SESSION['username'] ?? 'Waiter';

// Fetch waiter stats
$stats = ['active' => 0, 'completed' => 0, 'pending' => 0];
try {
    $stmt = $db->prepare("
        SELECT 
          SUM(status = 'preparing') AS active,
          SUM(status = 'served') AS completed,
          SUM(status = 'pending') AS pending
        FROM waiter_orders
        WHERE waiter_id = :id
    ");
    $stmt->execute([':id' => $user_id]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC) ?: $stats;
} catch (PDOException $e) {
    error_log('Waiter dashboard stats error: ' . $e->getMessage());
}

// Fetch profile image
$profile_img = 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png';
try {
    $stmt = $db->prepare("SELECT profile_image FROM user WHERE id = :id");
    $stmt->execute([':id' => $user_id]);
    $imgRow = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!empty($imgRow['profile_image'])) {
        $profile_img = '../../../uploads/profiles/' . htmlspecialchars($imgRow['profile_image']);
    }
} catch (PDOException $e) {
    error_log('Profile image fetch failed: ' . $e->getMessage());
}

ob_start();
?>

<div class="container-fluid py-3">

  <!-- Header -->
  <div class="page-title-box d-flex justify-content-between align-items-center mb-4 flex-wrap">
    <div>
      <h3 class="mb-1">Welcome, <?= htmlspecialchars($user_name); ?> 👋</h3>
      <p class="text-muted mb-0">Manage your tables, orders, and support tasks efficiently.</p>
    </div>
    <div class="text-end mt-2 mt-sm-0">
      <div class="fw-medium fs-5 text-warning" id="liveTime"></div>
      <div class="text-muted small" id="liveDate"></div>
    </div>
  </div>

  <!-- Stats -->
  <div class="row g-3 mb-4">
    <div class="col-md-4">
      <div class="card p-3 shadow-sm border-0">
        <div class="d-flex align-items-center">
          <div class="me-3 text-warning"><i class="bi bi-list-check fs-3"></i></div>
          <div>
            <h4 class="mb-0"><?= $stats['active']; ?></h4>
            <small class="text-muted">Active Orders</small>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card p-3 shadow-sm border-0">
        <div class="d-flex align-items-center">
          <div class="me-3 text-success"><i class="bi bi-check-circle fs-3"></i></div>
          <div>
            <h4 class="mb-0"><?= $stats['completed']; ?></h4>
            <small class="text-muted">Completed Orders</small>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card p-3 shadow-sm border-0">
        <div class="d-flex align-items-center">
          <div class="me-3 text-secondary"><i class="bi bi-clock-history fs-3"></i></div>
          <div>
            <h4 class="mb-0"><?= $stats['pending']; ?></h4>
            <small class="text-muted">Pending Orders</small>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Profile & Quick Actions -->
  <div class="row g-3 align-items-stretch">
    <!-- Profile -->
    <div class="col-lg-4 d-flex">
      <div class="card border-0 flex-fill shadow-sm text-center">
        <div class="card-body">
          <img src="<?= $profile_img ?>" alt="Profile" class="rounded-circle shadow-sm mb-3" width="100" height="100">
          <h5 class="fw-semibold mb-0"><?= htmlspecialchars($user_name); ?></h5>
          <p class="text-muted small mb-3">Waiter</p>
          <div class="d-grid gap-2">
            <a href="profile.php" class="btn btn-warning text-white">
              <i class="bi bi-person-lines-fill me-1"></i> View Profile
            </a>
            <a href="orders.php" class="btn btn-outline-warning">
              <i class="bi bi-list-check me-1"></i> My Orders
            </a>
            <a href="../../../logout.php" class="btn btn-outline-danger">
              <i class="bi bi-box-arrow-right me-1"></i> Logout
            </a>
          </div>
        </div>
      </div>
    </div>

    <!-- Quick Actions -->
    <div class="col-lg-8 d-flex">
      <div class="card border-0 flex-fill shadow-sm text-center">
        <div class="card-header bg-white fw-bold border-bottom">
          <i class="bi bi-lightning-charge text-warning me-2"></i>Quick Actions
        </div>
        <div class="card-body">
          <div class="row g-3">
            <div class="col-4">
              <a href="orders.php" class="text-decoration-none d-block">
                <i class="bi bi-list-check fs-2 text-warning"></i>
                <div class="fw-medium mt-2">Orders</div>
              </a>
            </div>
            <div class="col-4">
              <a href="tables.php" class="text-decoration-none d-block">
                <i class="bi bi-grid fs-2 text-warning"></i>
                <div class="fw-medium mt-2">Tables</div>
              </a>
            </div>
            <div class="col-4">
              <!-- ✅ Updated to open scan_qr.php -->
              <a href="scan_qr.php" class="text-decoration-none d-block">
                <i class="bi bi-qr-code-scan fs-2 text-warning"></i>
                <div class="fw-medium mt-2">Scan / Support Order</div>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Tips -->
  <div class="card mt-4 border-0 shadow-sm">
    <div class="card-header bg-white fw-bold border-bottom">
      <i class="bi bi-info-circle text-warning me-2"></i> Helpful Tips
    </div>
    <div class="card-body">
      <ul class="mb-0">
        <li><strong>Orders:</strong> Manage your assigned orders efficiently.</li>
        <li><strong>Tables:</strong> Track active and available tables.</li>
        <li><strong>Scan / Support Order:</strong> Start a new order by scanning a table QR or entering manually.</li>
        <li><strong>Support Mode:</strong> Handles guest or walk-in users.</li>
      </ul>
    </div>
  </div>
</div>

<!-- Notifications -->
<div class="toast-container position-fixed top-0 end-0 p-3" id="notificationContainer" style="z-index:1200;"></div>

<script>
// === Live Time ===
function updateDateTime() {
  const now = new Date();
  document.getElementById('liveTime').textContent = now.toLocaleTimeString();
  document.getElementById('liveDate').textContent = now.toLocaleDateString();
}
setInterval(updateDateTime, 1000);
updateDateTime();

// === Notifications ===
function markAsRead(id) {
  fetch('mark_notification.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'id=' + id
  }).then(() => {
    const toast = document.querySelector(`.toast[data-id="${id}"]`);
    if (toast) toast.remove();
  });
}

function fetchNotifications() {
  fetch('fetch_notifications.php')
    .then(res => res.text())
    .then(html => {
      if (html.trim()) {
        const container = document.getElementById('notificationContainer');
        container.insertAdjacentHTML('afterbegin', html);
        new Audio('https://cdn.pixabay.com/download/audio/2022/03/15/audio_2c4a0f4b92.mp3?filename=beep-6-96243.mp3').play();
        document.querySelectorAll('.toast').forEach(el => {
          new bootstrap.Toast(el, { delay: 10000 }).show();
        });
      }
    })
    .catch(console.error);
}
setInterval(fetchNotifications, 10000);
</script>

<?php
$content = ob_get_clean();
include '../../layouts/app.php';
?>
